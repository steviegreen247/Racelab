# RaceLab — phase 1

Mobile-friendly Streamlit horse-racing research dashboard. Upload legitimately obtained historical race results CSV, then train and evaluate winner/place prediction models with a chronological holdout. Predictions are calculated only from provided data; no racing data or insider information is fabricated.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy

Create a GitHub repository containing these files. Deploy via Streamlit Community Cloud, selecting `app.py` as the entry point. Hosting and resource limits depend on the provider's current free tier.

## Data requirements

CSV columns: `race_id,race_date,horse,finish_position,field_size,odds_decimal,days_since_run,prior_runs,prior_wins,prior_places,prior_avg_finish,draw,distance_furlongs,going_code,trainer_30d_win_rate,jockey_30d_win_rate`.

All predictor values MUST reflect knowledge before race off-time. `odds_decimal` must be the pre-race quote, not an eventual payout. Include every runner. Avoid leaking results, future form, or post-race odds into features. Race dates and IDs must be consistent. Place definitions are simplified; account for race-specific terms in production.

## Next phases

1. License historical UK/Irish results and pre-race data; ingest incrementally with provenance.
2. Add scheduled updates, immutable pre-off predictions, public trainer statements and source links.
3. Implement rolling-origin validation, calibration, baseline comparison, leakage audits and stratification by field size and race type.
4. Add database, daily racecards, filters and automated monitoring. Never represent public reporting as private insider knowledge.

This is a research prototype, not a live feed or a demonstrated profitable betting system.
